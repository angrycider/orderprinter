#include <Arduino.h>
void printQR(String message);